import java.util.ArrayList;

public class Goal {
    public int row;
    public int col;
    public Goal(int goalRow, int goalCol) {
        this.row = goalRow;
        this.col = goalCol;
    }
}
