public class BlankSquare extends Square {
    public BlankSquare(){
        color = Color.BLANK;
        shape = Shape.BLANK;
    }

}
