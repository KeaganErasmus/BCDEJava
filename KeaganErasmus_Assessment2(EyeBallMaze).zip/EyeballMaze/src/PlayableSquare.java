public class PlayableSquare extends Square{
    public PlayableSquare(Color color, Shape shape){
        this.color = color;
        this.shape = shape;
    }
}
