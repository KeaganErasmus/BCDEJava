public class Square {
    public int col;
    public int row;
    public Color color;
    public Shape shape;

    public int getRow(){
        return this.row;
    }
    public int getCol(){
        return this.col;
    }
}
