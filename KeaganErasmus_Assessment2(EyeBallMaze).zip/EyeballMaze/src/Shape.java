public enum Shape {
    DIAMOND, CROSS, STAR, FLOWER, BLANK, LIGHTNING
}
