public enum Color {
    BLUE, RED, YELLOW, GREEN, BLANK, PURPLE
}